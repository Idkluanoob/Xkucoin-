# xKuCoin - Auto Claim Bot

🔗 **Referral Link**: [xKuCoin](https://t.me/xkucoinbot/kucoinminiapp?startapp=cm91dGU9JTJGdGFwLWdhbWUlM0ZpbnZpdGVyVXNlcklkJTNENTkxNDk4MjU2NCUyNnJjb2RlJTNE)

## 📢 Telegram Group

Join our Telegram group to stay updated and get instructions on how to use this tool:

- [Smart Airdrop](https://t.me/AirdropScript6)
- [Smart Airdrop - Channel](https://t.me/AirdropScript6)

## 🌟 Features

| Feature  | Status  | Description                  |
| -------- | ------- | ---------------------------- |
| Auto Tap | Default | Tap based on available worms |

## 🚀 Run File

| Run with Proxy                   | Run without Proxy   |
| -------------------------------- | ------------------- |
| `bot-proxy.py` `data-proxy.json` | `bot.py` `data.txt` |

## ⚠️ Note

- Get auth data (`query_id=... /user=...`) in the `Application` tab in DevTools.
- Supported commands: `/run_bot` `/query_id` `/proxy` `/proxy_web` (Join group to use these commands).
